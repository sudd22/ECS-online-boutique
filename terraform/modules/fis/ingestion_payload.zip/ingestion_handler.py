import json
import urllib.request
import datetime
import os
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)
WEBHOOK_URL = os.environ['WEBHOOK_URL']
API_KEY = os.environ['API_KEY']

def lambda_handler(event, context):
    detail = event.get('detail', {})
    alarm_name = detail.get('alarmName', 'Unknown-Alarm')
    state = detail.get('state', {})
    state_value = state.get('value', 'ALARM')
    reason = state.get('reason', 'No reason provided')

    action = 'created'
    if state_value == 'OK':
        action = 'resolved'

    timestamp = datetime.datetime.utcnow().isoformat() + 'Z'

    payload = {
        "eventType": "incident",
        "incidentId": event.get('id', 'incident-123'),
        "action": action,
        "priority": "HIGH",
        "title": alarm_name,
        "description": reason,
        "timestamp": timestamp,
        "service": "b2b-monolith",
        "data": event
    }

    headers = {
        "Content-Type": "application/json",
        "x-amzn-event-timestamp": timestamp,
        "Authorization": f"Bearer {API_KEY}",
        "x-api-key": API_KEY,
    }

    req = urllib.request.Request(
        WEBHOOK_URL,
        data=json.dumps(payload).encode("utf-8"),
        headers=headers,
        method="POST",
    )

    try:
        with urllib.request.urlopen(req) as response:
            res_body = response.read().decode('utf-8')
            logger.info("DevOps Agent webhook response: %s", res_body)
            return {
                "statusCode": 200,
                "body": res_body
            }
    except Exception as e:
        logger.error("Error posting to webhook: %s", e)
        if hasattr(e, 'read'):
            try:
                err_body = e.read().decode('utf-8')
                logger.error("Webhook error response body: %s", err_body)
            except Exception:
                pass
        raise
